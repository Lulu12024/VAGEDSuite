namespace VAGSuite
{
    partial class frmSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.Utils.SuperToolTip superToolTip19 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem19 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem19 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem2 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem3 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem4 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem5 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem5 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem6 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem6 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem7 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem7 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip8 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem8 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem8 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip9 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem9 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem9 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip10 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem10 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem10 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip11 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem11 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem11 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip12 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem12 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem12 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip13 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem13 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem13 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip14 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem14 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem14 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip15 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem15 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem15 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip16 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem16 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem16 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip18 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem18 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem18 = new DevExpress.Utils.ToolTipItem();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.checkEdit11 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.comboBoxEdit2 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.checkEdit15 = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.checkEdit20 = new DevExpress.XtraEditors.CheckEdit();
            this.comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.checkEdit14 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit12 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit10 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit9 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit8 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit7 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit5 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit4 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit2 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.buttonEdit1 = new DevExpress.XtraEditors.ButtonEdit();
            this.checkEdit31 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit6 = new DevExpress.XtraEditors.CheckEdit();
            this.checkEdit3 = new DevExpress.XtraEditors.CheckEdit();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.checkEdit17 = new DevExpress.XtraEditors.CheckEdit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit11.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit15.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit20.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit14.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit12.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit10.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit9.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit8.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit7.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit31.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit17.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.checkEdit17);
            this.groupControl1.Controls.Add(this.checkEdit11);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.comboBoxEdit2);
            this.groupControl1.Controls.Add(this.checkEdit15);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Controls.Add(this.checkEdit20);
            this.groupControl1.Controls.Add(this.comboBoxEdit1);
            this.groupControl1.Controls.Add(this.checkEdit14);
            this.groupControl1.Controls.Add(this.checkEdit12);
            this.groupControl1.Controls.Add(this.checkEdit10);
            this.groupControl1.Controls.Add(this.checkEdit9);
            this.groupControl1.Controls.Add(this.checkEdit8);
            this.groupControl1.Controls.Add(this.checkEdit7);
            this.groupControl1.Controls.Add(this.checkEdit5);
            this.groupControl1.Controls.Add(this.checkEdit4);
            this.groupControl1.Controls.Add(this.checkEdit2);
            this.groupControl1.Controls.Add(this.checkEdit1);
            this.groupControl1.Location = new System.Drawing.Point(10, 12);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(704, 185);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "User interface settings";
            this.groupControl1.Paint += new System.Windows.Forms.PaintEventHandler(this.groupControl1_Paint);
            // 
            // checkEdit11
            // 
            this.checkEdit11.Location = new System.Drawing.Point(242, 77);
            this.checkEdit11.Name = "checkEdit11";
            this.checkEdit11.Properties.Caption = "Always synchronize mapviewers";
            this.checkEdit11.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem19.Text = "Always synchronize mapviewers";
            toolTipItem19.LeftIndent = 6;
            toolTipItem19.Text = "When checked, ALL the mapviewers will react to changes made in one of the viewers" +
                ". E.g. changing viewtype";
            superToolTip19.Items.Add(toolTipTitleItem19);
            superToolTip19.Items.Add(toolTipItem19);
            this.checkEdit11.SuperTip = superToolTip19;
            this.checkEdit11.TabIndex = 18;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(16, 130);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(126, 13);
            this.labelControl2.TabIndex = 17;
            this.labelControl2.Text = "Default view size for maps";
            // 
            // comboBoxEdit2
            // 
            this.comboBoxEdit2.EditValue = "Normal resolution screen (1280 * 1024)";
            this.comboBoxEdit2.Location = new System.Drawing.Point(244, 127);
            this.comboBoxEdit2.Name = "comboBoxEdit2";
            this.comboBoxEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit2.Properties.Items.AddRange(new object[] {
            "High resolution screen (1600 * 1200)",
            "Normal resolution screen (1280 * 1024)",
            "Low resolution screen (1024 * 768)"});
            this.comboBoxEdit2.Size = new System.Drawing.Size(210, 20);
            this.comboBoxEdit2.TabIndex = 16;
            // 
            // checkEdit15
            // 
            this.checkEdit15.EditValue = true;
            this.checkEdit15.Location = new System.Drawing.Point(242, 52);
            this.checkEdit15.Name = "checkEdit15";
            this.checkEdit15.Properties.Caption = "Synchronize equal mapviewers";
            this.checkEdit15.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem1.Text = "Synchronize mapviewers";
            toolTipItem1.LeftIndent = 6;
            toolTipItem1.Text = "When checked, all the mapviewers with the same symbol will react to changes made " +
                "in one of the viewers. E.g. changing viewtype";
            superToolTip1.Items.Add(toolTipTitleItem1);
            superToolTip1.Items.Add(toolTipItem1);
            this.checkEdit15.SuperTip = superToolTip1;
            this.checkEdit15.TabIndex = 15;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(16, 156);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(130, 13);
            this.labelControl1.TabIndex = 14;
            this.labelControl1.Text = "Default view type for maps";
            // 
            // checkEdit20
            // 
            this.checkEdit20.Location = new System.Drawing.Point(487, 102);
            this.checkEdit20.Name = "checkEdit20";
            this.checkEdit20.Properties.Caption = "Show addresses and lengths in Hex";
            this.checkEdit20.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem2.Text = "Show addresses and length in Hex";
            toolTipItem2.LeftIndent = 6;
            toolTipItem2.Text = "When checked, the address and length data for all the symbols will be shown in he" +
                "xadecimal format, otherwise in decimal.";
            superToolTip2.Items.Add(toolTipTitleItem2);
            superToolTip2.Items.Add(toolTipItem2);
            this.checkEdit20.SuperTip = superToolTip2;
            this.checkEdit20.TabIndex = 3;
            // 
            // comboBoxEdit1
            // 
            this.comboBoxEdit1.EditValue = "Easy view";
            this.comboBoxEdit1.Location = new System.Drawing.Point(244, 153);
            this.comboBoxEdit1.Name = "comboBoxEdit1";
            this.comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit1.Properties.Items.AddRange(new object[] {
            "Hexadecimal view",
            "Decimal view",
            "Easy view"});
            this.comboBoxEdit1.Size = new System.Drawing.Size(210, 20);
            this.comboBoxEdit1.TabIndex = 13;
            // 
            // checkEdit14
            // 
            this.checkEdit14.EditValue = true;
            this.checkEdit14.Location = new System.Drawing.Point(242, 28);
            this.checkEdit14.Name = "checkEdit14";
            this.checkEdit14.Properties.Caption = "Auto load last file on startup";
            this.checkEdit14.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem3.Text = "Auto load last file on startup";
            toolTipItem3.LeftIndent = 6;
            toolTipItem3.Text = "Lets you decide whether or not the last used file should be automatically loaded " +
                "when the program starts up.";
            superToolTip3.Items.Add(toolTipTitleItem3);
            superToolTip3.Items.Add(toolTipItem3);
            this.checkEdit14.SuperTip = superToolTip3;
            this.checkEdit14.TabIndex = 12;
            // 
            // checkEdit12
            // 
            this.checkEdit12.Location = new System.Drawing.Point(487, 77);
            this.checkEdit12.Name = "checkEdit12";
            this.checkEdit12.Properties.Caption = "New panels are floating";
            this.checkEdit12.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem4.Text = "New panels are floating";
            toolTipItem4.LeftIndent = 6;
            toolTipItem4.Text = "When checked makes new viewer float inside the application window in stead of doc" +
                "king them to the right side of the screen.";
            superToolTip4.Items.Add(toolTipTitleItem4);
            superToolTip4.Items.Add(toolTipItem4);
            this.checkEdit12.SuperTip = superToolTip4;
            this.checkEdit12.TabIndex = 10;
            // 
            // checkEdit10
            // 
            this.checkEdit10.Location = new System.Drawing.Point(487, 53);
            this.checkEdit10.Name = "checkEdit10";
            this.checkEdit10.Properties.Caption = "Auto dock maps with same name";
            this.checkEdit10.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem5.Text = "Auto dock maps with same name";
            toolTipItem5.LeftIndent = 6;
            toolTipItem5.Text = "When checked EDCSuite will dock newly started mapviewers to eachother whenever th" +
                "ey display the same symbol.";
            superToolTip5.Items.Add(toolTipTitleItem5);
            superToolTip5.Items.Add(toolTipItem5);
            this.checkEdit10.SuperTip = superToolTip5;
            this.checkEdit10.TabIndex = 8;
            // 
            // checkEdit9
            // 
            this.checkEdit9.Location = new System.Drawing.Point(487, 28);
            this.checkEdit9.Name = "checkEdit9";
            this.checkEdit9.Properties.Caption = "Auto dock maps from same file";
            this.checkEdit9.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem6.Text = "Auto dock maps from same file";
            toolTipItem6.LeftIndent = 6;
            toolTipItem6.Text = "When checked EDCSuite will dock newly started mapviewers to eachother whenever th" +
                "ey are from the same binary file.";
            superToolTip6.Items.Add(toolTipTitleItem6);
            superToolTip6.Items.Add(toolTipItem6);
            this.checkEdit9.SuperTip = superToolTip6;
            this.checkEdit9.TabIndex = 7;
            // 
            // checkEdit8
            // 
            this.checkEdit8.Location = new System.Drawing.Point(10, 103);
            this.checkEdit8.Name = "checkEdit8";
            this.checkEdit8.Properties.Caption = "Don\'t display colors in mapviewer";
            this.checkEdit8.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem7.Text = "Don\'t display colors in mapviewer";
            toolTipItem7.LeftIndent = 6;
            toolTipItem7.Text = "To improve performance you can check this item and coloring of the mapviewer cell" +
                "s will be disabled.";
            superToolTip7.Items.Add(toolTipTitleItem7);
            superToolTip7.Items.Add(toolTipItem7);
            this.checkEdit8.SuperTip = superToolTip7;
            this.checkEdit8.TabIndex = 6;
            // 
            // checkEdit7
            // 
            this.checkEdit7.Location = new System.Drawing.Point(10, 53);
            this.checkEdit7.Name = "checkEdit7";
            this.checkEdit7.Properties.Caption = "Auto size columns in mapviewer";
            this.checkEdit7.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem8.Text = "Auto size columns in mapviewer";
            toolTipItem8.LeftIndent = 6;
            superToolTip8.Items.Add(toolTipTitleItem8);
            superToolTip8.Items.Add(toolTipItem8);
            this.checkEdit7.SuperTip = superToolTip8;
            this.checkEdit7.TabIndex = 5;
            // 
            // checkEdit5
            // 
            this.checkEdit5.Location = new System.Drawing.Point(242, 102);
            this.checkEdit5.Name = "checkEdit5";
            this.checkEdit5.Properties.Caption = "Show graphs in mapviewer";
            this.checkEdit5.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem9.Text = "Show graphs in mapviewer";
            toolTipItem9.LeftIndent = 6;
            toolTipItem9.Text = "When checked the graphical representation of the selected map will also be displa" +
                "yed. This consumes more system memory en cpu time.";
            superToolTip9.Items.Add(toolTipTitleItem9);
            superToolTip9.Items.Add(toolTipItem9);
            this.checkEdit5.SuperTip = superToolTip9;
            this.checkEdit5.TabIndex = 3;
            // 
            // checkEdit4
            // 
            this.checkEdit4.Location = new System.Drawing.Point(487, 128);
            this.checkEdit4.Name = "checkEdit4";
            this.checkEdit4.Properties.Caption = "View tables in hexadecimal values";
            this.checkEdit4.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem10.Text = "View tables in hexadecimal values";
            toolTipItem10.LeftIndent = 6;
            toolTipItem10.Text = "When checked, tables will be shown in hexadecimal values as default. \r\nOtherwise " +
                "maps will  be displayed in easy mode when they are opened.";
            superToolTip10.Items.Add(toolTipTitleItem10);
            superToolTip10.Items.Add(toolTipItem10);
            this.checkEdit4.SuperTip = superToolTip10;
            this.checkEdit4.TabIndex = 2;
            // 
            // checkEdit2
            // 
            this.checkEdit2.Location = new System.Drawing.Point(10, 78);
            this.checkEdit2.Name = "checkEdit2";
            this.checkEdit2.Properties.Caption = "Use red and white maps";
            this.checkEdit2.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem11.Text = "Use red and white maps";
            toolTipItem11.LeftIndent = 6;
            toolTipItem11.Text = "When checked, displays maps in red and transparent only. Normally green is used t" +
                "o display low values and red for higher values.";
            superToolTip11.Items.Add(toolTipTitleItem11);
            superToolTip11.Items.Add(toolTipItem11);
            this.checkEdit2.SuperTip = superToolTip11;
            this.checkEdit2.TabIndex = 1;
            // 
            // checkEdit1
            // 
            this.checkEdit1.Location = new System.Drawing.Point(10, 28);
            this.checkEdit1.Name = "checkEdit1";
            this.checkEdit1.Properties.Caption = "Auto size new mapwindows";
            this.checkEdit1.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem12.Text = "Auto size new mapwindows";
            toolTipItem12.LeftIndent = 6;
            toolTipItem12.Text = "When checked, new mapwindows will try to autosize to fit the displayed table.";
            superToolTip12.Items.Add(toolTipTitleItem12);
            superToolTip12.Items.Add(toolTipItem12);
            this.checkEdit1.SuperTip = superToolTip12;
            this.checkEdit1.TabIndex = 0;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.labelControl4);
            this.groupControl2.Controls.Add(this.buttonEdit1);
            this.groupControl2.Controls.Add(this.checkEdit31);
            this.groupControl2.Controls.Add(this.checkEdit6);
            this.groupControl2.Controls.Add(this.checkEdit3);
            this.groupControl2.Location = new System.Drawing.Point(10, 203);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(704, 92);
            this.groupControl2.TabIndex = 1;
            this.groupControl2.Text = "General settings";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(245, 58);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(65, 13);
            this.labelControl4.TabIndex = 11;
            this.labelControl4.Text = "Project folder";
            // 
            // buttonEdit1
            // 
            this.buttonEdit1.Location = new System.Drawing.Point(328, 57);
            this.buttonEdit1.Name = "buttonEdit1";
            this.buttonEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.buttonEdit1.Size = new System.Drawing.Size(343, 20);
            toolTipTitleItem13.Text = "Project folder";
            toolTipItem13.LeftIndent = 6;
            toolTipItem13.Text = "Allows you to change the default project folder.";
            superToolTip13.Items.Add(toolTipTitleItem13);
            superToolTip13.Items.Add(toolTipItem13);
            this.buttonEdit1.SuperTip = superToolTip13;
            this.buttonEdit1.TabIndex = 10;
            // 
            // checkEdit31
            // 
            this.checkEdit31.Location = new System.Drawing.Point(5, 57);
            this.checkEdit31.Name = "checkEdit31";
            this.checkEdit31.Properties.Caption = "Request project notes";
            this.checkEdit31.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem14.Text = "Request project notes";
            toolTipItem14.LeftIndent = 6;
            toolTipItem14.Text = "When you are working in a project and want to keep track of what you have done, y" +
                "ou can have the software ask you for a remark every time you make a change to on" +
                "e of the maps or axis.";
            superToolTip14.Items.Add(toolTipTitleItem14);
            superToolTip14.Items.Add(toolTipItem14);
            this.checkEdit31.SuperTip = superToolTip14;
            this.checkEdit31.TabIndex = 9;
            // 
            // checkEdit6
            // 
            this.checkEdit6.Location = new System.Drawing.Point(487, 32);
            this.checkEdit6.Name = "checkEdit6";
            this.checkEdit6.Properties.Caption = "Use code block synchroniser";
            this.checkEdit6.Size = new System.Drawing.Size(184, 19);
            toolTipTitleItem15.Text = "Use code block synchronizer";
            toolTipItem15.LeftIndent = 6;
            toolTipItem15.Text = "Allows the software to keep all codeblocks in the file synchronized. If data is w" +
                "ritten to a map in codeblock 1, the same maps in the other codeblocks will be ov" +
                "erwritten as well.";
            superToolTip15.Items.Add(toolTipTitleItem15);
            superToolTip15.Items.Add(toolTipItem15);
            this.checkEdit6.SuperTip = superToolTip15;
            this.checkEdit6.TabIndex = 4;
            // 
            // checkEdit3
            // 
            this.checkEdit3.Location = new System.Drawing.Point(5, 32);
            this.checkEdit3.Name = "checkEdit3";
            this.checkEdit3.Properties.Caption = "Auto update checksum";
            this.checkEdit3.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem16.Text = "Auto update checksum";
            toolTipItem16.LeftIndent = 6;
            toolTipItem16.Text = "... not yet implemented ... ";
            superToolTip16.Items.Add(toolTipTitleItem16);
            superToolTip16.Items.Add(toolTipItem16);
            this.checkEdit3.SuperTip = superToolTip16;
            this.checkEdit3.TabIndex = 2;
            // 
            // simpleButton1
            // 
            this.simpleButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.simpleButton1.Location = new System.Drawing.Point(639, 309);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(75, 23);
            this.simpleButton1.TabIndex = 2;
            this.simpleButton1.Text = "Ok";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.simpleButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.simpleButton2.Location = new System.Drawing.Point(558, 309);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(75, 23);
            this.simpleButton2.TabIndex = 3;
            this.simpleButton2.Text = "Cancel";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // checkEdit17
            // 
            this.checkEdit17.EditValue = true;
            this.checkEdit17.Location = new System.Drawing.Point(487, 153);
            this.checkEdit17.Name = "checkEdit17";
            this.checkEdit17.Properties.Caption = "Show table upside down";
            this.checkEdit17.Size = new System.Drawing.Size(212, 19);
            toolTipTitleItem18.Text = "Show tables upside down";
            toolTipItem18.LeftIndent = 6;
            toolTipItem18.Text = "Allows you to display all tables upside down.";
            superToolTip18.Items.Add(toolTipTitleItem18);
            superToolTip18.Items.Add(toolTipItem18);
            this.checkEdit17.SuperTip = superToolTip18;
            this.checkEdit17.TabIndex = 20;
            // 
            // frmSettings
            // 
            this.AcceptButton = this.simpleButton1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.simpleButton2;
            this.ClientSize = new System.Drawing.Size(726, 345);
            this.ControlBox = false;
            this.Controls.Add(this.simpleButton2);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.groupControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.frmSettings_Load);
            this.Shown += new System.EventHandler(this.frmSettings_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit11.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit15.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit20.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit14.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit12.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit10.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit9.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit8.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit7.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buttonEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit31.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit17.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.CheckEdit checkEdit1;
        private DevExpress.XtraEditors.CheckEdit checkEdit2;
        private DevExpress.XtraEditors.CheckEdit checkEdit3;
        private DevExpress.XtraEditors.CheckEdit checkEdit4;
        private DevExpress.XtraEditors.CheckEdit checkEdit5;
        private DevExpress.XtraEditors.CheckEdit checkEdit7;
        private DevExpress.XtraEditors.CheckEdit checkEdit10;
        private DevExpress.XtraEditors.CheckEdit checkEdit9;
        private DevExpress.XtraEditors.CheckEdit checkEdit8;
        private DevExpress.XtraEditors.CheckEdit checkEdit12;
        private DevExpress.XtraEditors.CheckEdit checkEdit14;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private DevExpress.XtraEditors.CheckEdit checkEdit15;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit2;
        private DevExpress.XtraEditors.CheckEdit checkEdit20;
        private DevExpress.XtraEditors.CheckEdit checkEdit6;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.ButtonEdit buttonEdit1;
        private DevExpress.XtraEditors.CheckEdit checkEdit31;
        private DevExpress.XtraEditors.CheckEdit checkEdit11;
        private DevExpress.XtraEditors.CheckEdit checkEdit17;
    }
}